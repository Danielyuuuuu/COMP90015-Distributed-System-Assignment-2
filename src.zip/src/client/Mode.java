package client;

public enum Mode {
	LINE,
	CIRCLE,
	OVAL,
	RECTANGLE,
	TEXT
}
