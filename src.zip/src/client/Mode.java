/*
 * The program is written by Yifei Yu
 * Student ID: 945753
 */

package client;

public enum Mode {
	LINE,
	CIRCLE,
	OVAL,
	RECTANGLE,
	TEXT,
	PEN
}
